<?php


    for  ( $i=1; $i<13; $i++) {
        for ($j=1; $j < 11 ; $j++) {
        echo $i . " x " . $j . " = " . $i * $j . PHP_EOL;
        }
            
    };

?>